#ifndef _Imath
#define _Imath 1

#include "queue.h"

extern char *merr;
double calc();
int umath();

#endif
