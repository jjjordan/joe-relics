/* Messages
   Copyright (C) 1992 Joseph H. Allen

This file is part of JOE (Joe's Own Editor)

JOE is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software 
Foundation; either version 1, or (at your option) any later version.  

JOE is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more 
details.  

You should have received a copy of the GNU General Public License along with 
JOE; see the file COPYING.  If not, write to the Free Software Foundation, 
675 Mass Ave, Cambridge, MA 02139, USA.  */ 

#ifndef _Imsgs
#define _Imsgs 1

#include "config.h"

extern char
 M001[], M002[], M003[], M004[], M005[], M006[], M007[], M008[],
 M009[], M010[], M011[], M012[], M013[], M014[], M015[], M016[],
 M017[], M018[], M019[], M020[], M021[], M022[], M023[], M024[],
 M025[], M026[], M027[], M028[], M029[], M030[], M031[], M032[],
 M033[], M034[], M035[], M036[], M037[], M038[], M039[], M040[],
 M041[], M042[], M043[], M044[], M045[], M046[], M047[], M048[],
 M049[], M050[], M051[], M052[], M053[], M054[], M055[], M056[],
 M057[], M058[], M059[], M060[], M061[], M062[], M063[], M064[],
 M065[], M066[], M067[], M068[], M069[], M070[], M071[], M072[],
 M073[], M074[], M075[], M076[], M077[], M078[], M079[], M080[],
 M081[], M082[], M083[], M084[], M085[], M086[], M087[], M088[],
 M089[], M090[];

#endif
